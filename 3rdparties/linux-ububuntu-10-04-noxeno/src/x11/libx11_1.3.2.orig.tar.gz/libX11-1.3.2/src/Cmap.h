/* $XFree86$ */

#ifndef _CMAP_H_
#define _CMAP_H_

extern void
_XcmsDeleteCmapRec(
    Display *dpy,
    Colormap cmap);

#endif /* _CMAP_H_ */
